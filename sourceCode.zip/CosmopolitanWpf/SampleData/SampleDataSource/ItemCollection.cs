﻿using System.Collections.ObjectModel;

namespace CosmopolitanWpf.SampleData.SampleDataSource
{
    /// <summary>
    /// This represent an OnservableCollection of Item.
    /// </summary>
	public class ItemCollection : ObservableCollection<Item>
	{
	}
}
