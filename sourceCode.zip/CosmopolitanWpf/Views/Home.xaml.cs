﻿using System.Windows.Controls;

namespace CosmopolitanWpf.Views
{
	/// <summary>
	/// Interaction logic for Home.xaml
	/// </summary>
	public partial class Home : UserControl
	{
        /// <summary>
        /// Initializes a new instance of the Home class.
        /// </summary>
		public Home()
		{
			InitializeComponent();
		}
	}
}
