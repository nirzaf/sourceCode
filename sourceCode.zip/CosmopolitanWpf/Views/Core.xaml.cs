﻿using System.Windows.Controls;

namespace CosmopolitanWpf.Views
{
	/// <summary>
	/// Interaction logic for Core.xaml
	/// </summary>
	public partial class Core : UserControl
	{
        /// <summary>
        /// Initializes a new instance of the Core class.
        /// </summary>
		public Core()
		{
			InitializeComponent();
		}
	}
}
